import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loading_indicator/loading_indicator.dart';
import 'package:referaly/languages/languagekeys.dart';
import 'package:referaly/resources/app_helper.dart';
import 'package:referaly/widgets/logo_loader.dart';

import '../../controller/controller_forgot.dart';
import '../../resources/app_colors.dart';
import '../../utils/translations.dart';
import '../../widgets/custom_auth_app_bar.dart';
import '../../widgets/primary_button.dart'; // Assuming you're using GetX for state management

class ScreenForgotPassword extends GetView<ForgotPasswordController> {
  ScreenForgotPassword({super.key});
  static const String pageId = '/ScreenForgotPassword';
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: const CustomAuthAppBar(),
        backgroundColor: AppColors.whiteColor,
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tr(LanguageKeys.forgotPassword),
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: AppColors
                              .blackColor, // Or your preferred heading color
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        tr(LanguageKeys.forgotPassSubtext),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          color:
                              Colors.grey, // Or your preferred subtitle color
                        ),
                      ),
                      const SizedBox(height: 32),
                      // Use the custom label and underline field
                      _buildLabel(tr(LanguageKeys.email), isRequired: true),
                      _buildUnderlineField(
                        controllerr: controller.tcEmail,
                        hintText: tr(LanguageKeys.enterYourEmail),
                        keyboardType: TextInputType.emailAddress,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return tr(LanguageKeys.pleaseEnterEmail);
                          }
                          if (!value.contains('@')) {
                            return tr(LanguageKeys.pleaseEnterValidEmail);
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 40),
                      Obx(
                        () => controller.isLoadingForgotPassword.isTrue
                            ? SizedBox(
                                width: 24,
                                height: 24,
                                child: LogoLoader(color: AppColors.whiteColor))
                            : PrimaryButton(
                                text: tr(LanguageKeys.Continue),
                                onPressed: controller
                                        .isLoadingForgotPassword.isFalse
                                    ? () async {
                                        AppHelper.hideKeyboard(context);
                                        if (_formKey.currentState!.validate()) {
                                          await controller.forgotPasswordApi();
                                        }
                                      }
                                    : null,
                                borderRadius: 12,
                                disabledBackgroundColor:
                                    Colors.grey[300], // Example disabled color
                              ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // _buildLabel widget to display the label with an optional required marker
  Widget _buildLabel(String text, {bool isRequired = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Text(
            text,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          ),
          if (isRequired)
            const Text(' *', style: TextStyle(color: Colors.red, fontSize: 16)),
        ],
      ),
    );
  }

  // _buildUnderlineField widget to build a TextFormField with a custom design
  Widget _buildUnderlineField({
    required TextEditingController controllerr,
    required String hintText,
    bool obscureText = false,
    Widget? suffixIcon,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: TextFormField(
        controller: controllerr,
        obscureText: obscureText,
        keyboardType: keyboardType,
        validator: validator,
        decoration: InputDecoration(
          hintText: hintText,
          isDense: true,
          filled: true,
          fillColor: Colors.black.withOpacity(0.045),
          hintStyle: const TextStyle(color: Colors.grey),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          suffixIcon: suffixIcon,
        ),
      ),
    );
  }
}
